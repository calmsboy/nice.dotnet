import MainLayout from '@wbh/Layout/MainLayout.vue'


const meta = {
  auth: true
}

const pre = ''

export default {
  path: '/home',
  name: 'home',
  header: 'home',
  redirect: {
    name: `${pre}home_index`
  },
  meta,
  component: MainLayout,
  children: [
    {
      path: 'index',
      name: `${pre}home_index`,
      header: 'index',
      meta: {
        auth: true,//['file-home-index'],
        title: '列尾解析软件主界面'
      },
      component: () => import('@wbh/views/front/HomeView.vue')
    }
  ]
}
