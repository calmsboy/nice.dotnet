import MainLayout from '@wbh/Layout/MainLayout.vue';
import HomeRouter from './modules/home'
import DemoHomeView from '@wbh/views/HomeView.vue'
/**
 * 在主框架内显示
 */

const backendFrame = [
  {
    path: '/',
    meta: {
      title: '列尾解析软件'
    },
    redirect: {
      name: 'home'//admin_index
    },
    component: MainLayout,
    children: [
      // {
      //   path: '/admin/system/log',
      //   name: 'log',
      //   meta: {
      //     title: '前端日志',
      //     auth: true
      //   },
      //   component: () => import('@/pages/system/log')
      // },
      // 刷新页面 必须保留
      {
        path: 'refresh',
        name: 'refresh',
        hidden: true,
        component: {
          beforeRouteEnter(to: any,
            from: { fullPath: any }, next: (arg0: (instance: any) => any) => void) {
            next(instance => instance.$router.replace(from.fullPath))
          },
          render: (h: any) => h()
        }
      },
      // 页面重定向 必须保留
      {
        path: 'redirect/:route*',
        name: 'redirect',
        hidden: true,
        component: {
          beforeRouteEnter(to: any, from: any, next: any) {
            // console.log(rom.params.route)
            next((instance: any) => instance.$router.replace(JSON.parse(from.params.route)))
          },
          render: (h: any) => h()
        }
      }
    ]
  },
  HomeRouter,
]
// 主框架外的
//各个登录页面
const authPages = [
  {
    path: '/demo/home',
    name: 'demo_home',
    component: DemoHomeView
  },
  {
    path: '/demo/about',
    name: 'demo_about',
    // route level code-splitting
    // this generates a separate chunk (About.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import('../views/AboutView.vue')
  }
  // {
  //   path: '/oauth',
  //   name: 'oauth',
  //   meta: {
  //     title: '云盘登录'
  //   },
  //   component: () => import('@/views/oauth/index.vue')
  // },
  // {
  //   path: '/file/sharelock',
  //   name: 'sharelock',
  //   meta: {
  //     title: '提取文件'
  //   },
  //   component: () => import('@/views/share/lock.vue')
  // },
]

// 导出需要显示菜单的
export const frameInRoutes = backendFrame

// 重新组织后导出
export default [
  ...backendFrame,
  ...authPages,
  //...frameOuts,
  //...errorPage

]