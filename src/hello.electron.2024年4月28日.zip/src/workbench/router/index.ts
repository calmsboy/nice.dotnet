import { createRouter, createWebHistory } from 'vue-router'
import NProgress from 'nprogress' // 引入nprogress插件
import 'nprogress/nprogress.css' // 这个nprogress样式必须引入
import routes from './routers'

//全局进度条的配置
NProgress.configure({
  showSpinner: false,  //加载微调器设置,默认为true
  easing: 'ease',
  speed: 1500
})
const routerHistory = createWebHistory()
const router = createRouter({
  history: routerHistory,
  routes: routes
})


/**
 * 路由拦截
 * 权限验证
 */
const testEnv = true;
router.beforeEach(async (to, from, next) => {
  //  console.log("to:",to)
  //  console.log("from:",from)
  //  const accountStore = useAccountStore()
  if (to.meta.title) document.title = String(to.meta.title)
  NProgress.start()
  if (to.matched.some(_ => _.meta.auth)) {
    //if (testEnv) return next();
    // 这里依据 userid 判断是否登录，可视情况修改

    if (testEnv) {
      next()
      //  const access = store.state.userInfo.uniqueAuth
      //  const isPermission = includeArray(to.meta.auth, access)

    } else {
      // 没有登录的时候跳转到登录界面
      // 携带上登陆成功之后需要跳转的页面完整路径
      // console.log("执行到跳转登录页面...")
      next()
      // next({
      //   name: 'oauth',
      //   query: {
      //     redirect: to.fullPath
      //   }
      // })
    }
  } else {
    next()
  }
})
router.afterEach(to => {

  // if (Setting.showProgressBar) iView.LoadingBar.finish()
  // 更改标题
  //setTitle(to, router.app)
  // 返回页面顶端
  window.scrollTo(0, 0)
  NProgress.done()
})


export default router
