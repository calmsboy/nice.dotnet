<template>
  <div class="wrapper">
    <RouterView />
  </div>
</template>

<script setup lang="ts">
import { RouterView } from 'vue-router';


</script>

<style scoped>
.wrapper {
  width: 100%;
}
</style>