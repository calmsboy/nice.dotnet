<template>
  <RouterView />
</template>

<script setup lang="ts">
import { RouterView } from 'vue-router'
console.log(
  "%c中铁列尾数据解析软件",
  " text-shadow: 0 1px 0 #ccc,0 2px 0 #c9c9c9,0 3px 0 #bbb,0 4px 0 #b9b9b9,0 5px 0 #aaa,0 6px 1px rgba(0,0,0,.1),0 0 5px rgba(0,0,0,.1),0 1px 3px rgba(0,0,0,.3),0 3px 5px rgba(0,0,0,.2),0 5px 10px rgba(0,0,0,.25),0 10px 10px rgba(0,0,0,.2),0 20px 20px rgba(0,0,0,.15);font-size:3em"
)
console.info(
  "%cNC.View%cV0.1.1",
  "padding:4px;color:white;background:#023047;",
  "padding:4px;color:white;background:#219EBC"
)
console.info(
  "%c万丈高楼平地起-2024年4月27日",
  "padding:4px;color:white;background:#219EBC"
)
</script>

<style lang="scss" scoped>
.el-input.form-control {
  padding: 0px !important;
}

.el-input__inner {
  // padding: 0.7rem 0.7rem !important;
  padding-left: 6px !important;
  height: calc(1.25em + 1.4rem + 1px) !important;
}

.el-select .el-input__wrapper {
  padding-left: 0px;
}

#nprogress {}

#nprogress .bar {
  // background: rgb(255, 255, 255) !important;
  z-index: 9999 !important;
  background: linear-gradient(to right,
      #5156be 20%,
      #2ab57d 40%,
      #4ba6ef 60%,
      #ffbf53 80%,
      #fd625e 100%) !important;
}
</style>