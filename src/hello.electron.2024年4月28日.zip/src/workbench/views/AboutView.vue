<template>
  <div class="about">
    <h1>This is an about page</h1>
    <p>
      选择的文件路径:{{ filePath }}
    </p>
    <div class="container-full">
      <button class="btn btn-primary" @click="openFile">打开文件</button>
      <button class="btn btn-primary">打开文件</button>
    </div>
    <h3>文件内容为：</h3>
    <!-- <p>
      {{ content }}
    </p> -->
    <div v-html="content" class="w-100" style="height: auto;">
    </div>
  </div>
</template>
<script lang="ts" setup>
import { ElMessage } from 'element-plus';
import { ref } from 'vue';
import { Buffer } from 'buffer';
const filePath = ref('')
const content = ref('')
const openFile = async () => {
  window.eleAPI.sayMessage("你好, electron!");
  const filePathResult = await window.eleAPI.openFileDialog();
  if (!filePathResult) {
    ElMessage.error('未选择文件');
    return;
  }
  filePath.value = filePathResult;
  window.eleAPI.readFile(filePath.value);
  window.eleAPI.readFileResponse((res: any) => {
    console.log("响应：", res);
    if (!res.success) {
      ElMessage.error(res.message);
      return;
    }
    content.value = Buffer.from(res.data).toString()
  });
}
</script>
<style>
/* @media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
} */
</style>
