<template>
  <div class="current-view">
    <div class="action-bar">
      <ElButton type="primary" @click="openFile">打开文件</ElButton>
    </div>
    <div class="current-content">
      <div class="d-flex w-100">
        <p class="w-100" style="min-height: 200px;">{{ content.toString() }}</p>
      </div>
    </div>
    <h2>测试</h2>
  </div>
</template>

<script setup lang="ts">
import { ElButton, ElMessage } from 'element-plus';
import { ref } from 'vue';
import { Buffer } from 'buffer';
const filePath = ref('')
const content = ref('')
const analysisModes: string[] = ["4G400M设备", "15D列尾设备", "双模列尾设备", "新疆15D列尾设备", "固定中继设备", "可控列尾设备"]
const openFile = async () => {
  window.eleAPI.sayMessage("你好, electron!");
  const filePathResult = await window.eleAPI.openFileDialog();
  if (!filePathResult) {
    ElMessage.error('未选择文件');
    return;
  }
  filePath.value = filePathResult;
  const analysisResult = await window.analysisAPI.AnalyzeDataFromFilePath(analysisModes[1], filePath.value);

  // window.eleAPI.readFile(filePath.value);
  // window.eleAPI.readFileResponse((res: any) => {
  //   console.log("响应：", res);
  //   if (!res.success) {
  //     ElMessage.error(res.message);
  //     return;
  //   }
  //   content.value = Buffer.from(res.data).toString()//
  // });
}

</script>

<style scoped>
.current-view {
  display: flex;
  justify-content: stretch;
  align-items: center;
  flex-wrap: wrap;
  height: 100%;
  width: 100%;
}

.action-bar {
  width: 100%;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.current-content {
  width: 100%;
  height: auto;
  display: flex;
  justify-content: stretch;
  align-items: center;
  flex-wrap: wrap;
}
</style>