import path from 'path';
import os from 'os';
import fs from 'fs';
import grpc from "@grpc/grpc-js";
import protoLoader from "@grpc/proto-loader";

const PROTO_PATH = path.join(__dirname, '/../../src/server/protos/analysis_data.proto');

const packageDefinition = protoLoader.loadSync(
  PROTO_PATH,
  {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    //oneofs: true
  }
)
const analysis_proto: any = grpc.loadPackageDefinition(packageDefinition).analysis;
const grpcAPIPath = "localhost:8850"
const cert = grpc.credentials.createInsecure();
const client = new analysis_proto.AnalysisGrpcService(grpcAPIPath, cert);

// export class AnalysisClientService {

// }
/**
 * 数据解析服务
 * @returns 
 */
const AnalysisClientService = () => {

  /**
   * 根据文件路径解析数据
   * @param filePath 
   * @returns 
   */
  function AnalyzeDataFromFilePath(analysisMode: string, filePath: string): Promise<any> {

    return new Promise((resolve, reject) => {
      try {
        console.log('AnalyzeDataFromFilePath:', filePath)
        const call = client.AnalyzeDataFromFilePath({
          AnalysisMode: analysisMode,
          FilePath: filePath
        })
        call.on('error', function (error: any) {
          console.log('AnalyzeDataFromFilePath error:', error)
          // An error has occurred and the stream has been closed.
        });
        // console.log('AnalyzeDataFromFilePath call:', call)
        call.on('data', (data: any) => {
          console.log('AnalyzeDataFromFilePath data:', data)
        });
        const callback = (data: any) => {
          console.log('callback');
          resolve({ data: 'AnalyzeDataFromFilePath success' })
        }
        call.on('end', callback);

      } catch (error) {
        console.log('AnalyzeDataFromFilePath error:', error)
        reject(error)
      }
    })
  }
  return {
    /**
     * 根据文件路径解析数据
   * @param filePath 
   * @returns 
     */
    AnalyzeDataFromFilePath
  }
}
export default AnalysisClientService