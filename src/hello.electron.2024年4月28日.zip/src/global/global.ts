
const CONFIG_FILE_PATH = 'Hello.Ele'
const CONFIG_FILE_NAME = 'config.json' // 配置文件 文件名
const DEFAULT_CONFIG = {
  initFileName: 'Hello.Ele_user.dict.yaml',  // 初始文件信息
  baseURL: 'https://hello.ele',         // BASE_URL
  autoDeployOnAdd: false,                        // 添词后 是否自动布署
  autoDeployOnDelete: false,                     // 删词后 是否自动布署
  autoDeployOnEdit: false,                       // 编辑词条后 是否自动布署
  enterKeyBehavior: 'add',                       // add | search
  rimeHomeDir: '',                               // 配置文件主目录
  rimeExecDir: '',                               // 输入法程序主目录
  searchMethod: 'both',                          // 搜索匹配的内容  code | phrase | both | any
  chosenGroupIndex: -1,                          // 列表中选定的分组 id
  theme: 'auto',                                 // auto 跟随系统 | black
  hasSetDictMap: false,                          // 是否已经设置字典码表文件
  isToolPanelShowing: true,                       // index.html 工具面板是否展开
  fileNameList: [],                               // 匹配文件名，显示自定义码表文件的名字
  // [{ "name": "luna_pinyin.sogou", "path": "luna_pinyin.sogou.dict.yaml" }]
}

export { CONFIG_FILE_PATH, CONFIG_FILE_NAME, DEFAULT_CONFIG }