import type { ConfigEnv, UserConfig } from 'vite';
import { defineConfig } from 'vite';
import { pluginExposeRenderer } from './vite.base.config';
import vue from '@vitejs/plugin-vue';
import { resolve } from 'path';
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
// https://vitejs.dev/config
export default defineConfig((env) => {
  const forgeEnv = env as ConfigEnv<'renderer'>;
  const { root, mode, forgeConfigSelf } = forgeEnv;
  const name = forgeConfigSelf.name ?? '';

  return {
    root,
    mode,
    base: './',
    build: {
      outDir: `.vite/renderer/${name}`,
    },
    plugins: [
      vue(),
      pluginExposeRenderer(name),
      AutoImport({
        resolvers: [ElementPlusResolver()],
      }),
      Components({
        resolvers: [ElementPlusResolver()],
      }),
    ],
    resolve: {
      preserveSymlinks: true,
      alias: {
        '@': resolve(__dirname, './src'),
        '@wbh': resolve(__dirname, './src/workbench'),
        '@wbhassets': resolve(__dirname, './src/workbench/assets'),
        '@wbhcomps': resolve(__dirname, './src/workbench/components'),
        '@wbhtools': resolve(__dirname, './src/workbench/tools'),
        '@wbhrouter': resolve(__dirname, './src/workbench/router'),
        '@wbhstore': resolve(__dirname, './src/workbench/store'),
        '@wbhservices': resolve(__dirname, './src/workbench/services'),
        '@wbhentities': resolve(__dirname, './src/workbench/entities'),
      }
    },
    clearScreen: false,
  } as UserConfig;
});
