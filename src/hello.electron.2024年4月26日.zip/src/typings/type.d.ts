export { }

export interface IEleAPI {
  sayMessage: (message: string) => Promise<void>;
  openFileDialog: () => Promise<string | null>;
  readFile: (filePath: string) => Promise<void>;
  readFileResponse: (callback: (event: any, data: Buffer) => void) => void;
}
declare global {
  interface Window {
    eleAPI: IEleAPI;
  }
}
declare module 'element-plus/dist/locale/zh-cn.mjs';