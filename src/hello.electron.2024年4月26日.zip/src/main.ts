import { app, BrowserWindow } from 'electron';
import path from 'path';
import { EleApplication } from './app';


class Programe {
  main() {
    try {
      this.startup();
    } catch (e) {
      console.log(e);
      app.exit(1);
    }
  }
  /**
   * 在这里配置要启动的主要服务
   */
  private async startup(): Promise<void> {
    console.log('准备服务中...');
    const application = new EleApplication();

    // Handle creating/removing shortcuts on Windows when installing/uninstalling.
    if (require('electron-squirrel-startup')) {
      app.quit();
    }

    //这个方法将在Electron完成时被调用
    //初始化，并准备创建浏览器窗口。
    //某些api只能在此事件发生后使用。
    app.on('ready', () => {
      application.startup();
    });

    //当所有窗口都关闭时退出，除了macOS。在那里，这很常见
    //让应用程序及其菜单栏保持活动状态，直到用户退出
    //显式地使用Cmd + Q。
    app.on('window-all-closed', () => {
      if (process.platform !== 'darwin') {
        app.quit();
      }
    });

    app.on('activate', () => {
      //在OS X上，通常会在应用程序中重新创建一个窗口
      //单击dock图标，没有其他窗口打开。
      if (BrowserWindow.getAllWindows().length === 0) {
        application.startup();
      }
    });

  }
}

const programe = new Programe();
//调用主程序
programe.main();