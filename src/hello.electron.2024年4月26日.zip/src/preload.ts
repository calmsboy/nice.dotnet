// See the Electron documentation for details on how to use preload scripts:

import { contextBridge, ipcRenderer } from "electron";

// https://www.electronjs.org/docs/latest/tutorial/process-model#preload-scripts
contextBridge.exposeInMainWorld('eleAPI', {
  sayMessage: (message: string) => ipcRenderer.invoke('ele:message', message),
  openFileDialog: () => ipcRenderer.invoke('ele:openFileDialog'),
  saveFileDialog: () => ipcRenderer.invoke('ele:saveFileDialog'),
  readFile: (filePath: string) => ipcRenderer.invoke('ele:readFile', filePath),
  readFileResponse: async (callback: (res: any) => void) => ipcRenderer.on('ele:readFileResponse', (event: any, res: any) => callback(res)),
})