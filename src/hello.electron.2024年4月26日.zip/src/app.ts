import { Event } from './base/common/event';
import { Disposable } from "./base/common/lifecycle";
import { app, BrowserWindow, dialog, ipcMain, IpcMainInvokeEvent } from 'electron';
import path from 'path';
import os from 'os';
import fs from 'fs';
import { CONFIG_FILE_PATH, DEFAULT_CONFIG, CONFIG_FILE_NAME } from "./global/global";

export class EleApplication extends Disposable {
  constructor() {
    super();
  }
  async startup(): Promise<void> {
    this.listenBrige();
    this.createWindow();
  }
  private createWindow(): void {
    // Create the browser window.
    const mainWindow = new BrowserWindow({
      width: 1000,
      height: 600,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        //nodeIntegration:是否集成node.js,默认为false
        nodeIntegration: true,
        //contextIsolation:上下文隔离,默认为true
        contextIsolation: true,
      },
    });
    // and load the index.html of the app.
    if (MAIN_WINDOW_VITE_DEV_SERVER_URL) {
      mainWindow.loadURL(MAIN_WINDOW_VITE_DEV_SERVER_URL);
    } else {
      mainWindow.loadFile(path.join(__dirname, `../renderer/${MAIN_WINDOW_VITE_NAME}/index.html`));
    }
    console.log("初始化窗口完成:", new Date().toLocaleString())
    // Open the DevTools.
    mainWindow.webContents.openDevTools();
    console.log("打开开发者工具完成:", new Date().toLocaleString())
  }
  /**
   * 添加IPC通信监听
   */
  private listenBrige(): void {

    ipcMain.handle('ele:message', handleSayMessage);
    ipcMain.handle('ele:openFileDialog', handleOpenFileDialog);
    ipcMain.handle('ele:readFile', handleReadFile)
  }
}


async function handleSayMessage(event: IpcMainInvokeEvent, message: string) {
  console.log(`收到消息:${message}`);
}

/**
 * 打开文件处理
 * @param event 
 * @returns 
 */
async function handleOpenFileDialog(event: IpcMainInvokeEvent) {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    properties: ['openFile'],
  })
  if (!canceled) {
    return filePaths[0]
  }
  return null
}
async function handleReadFile(event: IpcMainInvokeEvent, filePath: string) {
  if (!filePath || filePath.length == 0) {
    console.log("un expected filePath")
    event.sender.send('ele:readFileResponse', { success: false, message: "文件路径不能为空" });
    return
  }
  fs.readFile(filePath, (err, data) => {
    event.sender.send('ele:readFileResponse', { success: true, message: "读取成功", data: data })
  })

}
/**
 * 根据系统返回 ${appName} 配置路径
 * @param appName 
 * @returns 
 */
function getRimeConfigDir(appName: string) {
  const userHome = os.homedir()
  const config = readConfigFile()
  if (!config.rimeHomeDir) { // 没有设置配置文件目录时
    switch (os.platform()) {
      case 'aix':
        break
      case 'darwin':
        return path.join(`${userHome}/Library/${appName}`) // macOS
      case 'freebsd':
        break
      case 'linux':
        return path.join(`${userHome}/.config/ibus/${appName}`)
      case 'openbsd':
        break
      case 'sunos':
        break
      case 'win32':
        return path.join(`${userHome}/AppData/Roaming/${appName}`)// windows
    }
  } else {
    return config.rimeHomeDir
  }
}

function readConfigFile() {
  const configPath = path.join(os.homedir(), CONFIG_FILE_PATH)
  try { // 捕获读取文件时的错误，如果有配置文件 返回其内容，如果没有，返回  false
    const result = fs.readFileSync(path.join(configPath, CONFIG_FILE_NAME), { encoding: 'utf-8' })
    return JSON.parse(result)
  } catch (err) {
    return DEFAULT_CONFIG
  }
}